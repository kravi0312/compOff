package com.ia.lms;

public class Compoff {
	private int emp_id;
	private String comp_off_date, working_date,status;
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getComp_off_date() {
		return comp_off_date;
	}
	public void setComp_off_date(String comp_off_date) {
		this.comp_off_date = comp_off_date;
	}
	public String getWorking_date() {
		return working_date;
	}
	public void setWorking_date(String working_date) {
		this.working_date = working_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

}
