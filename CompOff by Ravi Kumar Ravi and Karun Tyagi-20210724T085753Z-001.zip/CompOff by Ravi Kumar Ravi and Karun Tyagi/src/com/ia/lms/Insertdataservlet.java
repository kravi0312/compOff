package com.ia.lms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Insertdataservlet
 */
@WebServlet("/Insertdataservlet")
public class Insertdataservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Insertdataservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("test/html");
		 PrintWriter out=response.getWriter();
		 String comp_off_date=request.getParameter("comp_off_date");
		 String working_date=request.getParameter("working_date");
		 String reason=request.getParameter("reason");
		 
		 /*
		 out.println(comp_off_date);
		 out.println(working_date);
		 out.println(reason);
		 */
		 
		 
		 //store into database using class compoff
		 
		 
		 Compoff compoffobj=new Compoff();
		 compoffobj.setComp_off_date(comp_off_date);
		 compoffobj.setWorking_date(working_date);
	
		 
		 Compoffinsert objinsert=new Compoffinsert();
		 //for email Sending
		 String msg="Compensatory Date : "+comp_off_date+"\n"+"Worked Date : "+working_date+"\n\n"+"Dear Manager\n"+reason;
	        String to=objinsert.manageremail(104).getManager_email();
	  
	        Sendmail.send(to, msg);
	        
	      //for insert data in data_base  
		  int index1=objinsert.save(compoffobj);  
	        if(index1>0){  
	        	response.sendRedirect("thnaku.html");  
	        }else{  
	            out.println("Sorry! unable to save record");  
	        }  
	          
	        out.close();
	        
	        
	                                                 
	        
	}

}
