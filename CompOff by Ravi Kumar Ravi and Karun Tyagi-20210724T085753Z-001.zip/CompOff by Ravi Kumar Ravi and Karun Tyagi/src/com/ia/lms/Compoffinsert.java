package com.ia.lms;

import java.io.*;  
import java.sql.*;
import java.util.ArrayList;
import java.util.List; 

public class Compoffinsert {
  //connection method
	public static Connection getConnection() throws Exception{  
	        Connection con=null;  
	        try{  
	            Class.forName("oracle.jdbc.driver.OracleDriver");  
	            con=DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.8:1521:QADB11G","MARUTI_MANU","abc123");  
	        }catch(Exception e){System.out.println(e);}  
	        return con;  
	    }  
	
	
//save data into database
	
	public static int save(Compoff comp_data)
	{
		int index=0;
		try{
		Connection con=Compoffinsert.getConnection();
		 PreparedStatement ps=con.prepareStatement("insert into EMP_COMP_OFF_STATUS(emp_id,comp_off_date,working_date) values(?,?,?) " );
				     ps.setInt(1,104);
				     ps.setString(2,comp_data.getComp_off_date());
				     ps.setString(3,comp_data.getWorking_date());
				     
				     index=ps.executeUpdate();
				     con.close();
	       	}catch(Exception ex){
			ex.printStackTrace();
		}
		return index;
	}
	
//Retrieve manager email address
	 public static Getsetmanageremail manageremail(int emp_id){  
		 Getsetmanageremail getemail=new Getsetmanageremail();  
	          
	        try{  
	            Connection con=Compoffinsert.getConnection();  
	            PreparedStatement ps=con.prepareStatement("select * from EMP_MANAGER_EMAIL where emp_id=?");  
	            ps.setInt(1,emp_id);  
	            ResultSet rs=ps.executeQuery();  
	            if(rs.next()){  
	            	//getmanageremail.setEmp_id(rs.getInt(1));
	            	getemail.setManager_email(rs.getString(2));
	            }  
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return getemail;  
	    }
	 
	 
	 //Search data from data base using year and month
	 
	 public static List<Compoff> getAllEmployees(String searchoption){  
	        List<Compoff> list=new ArrayList<Compoff>();  
	          
	        try{  
	            Connection con=Compoffinsert.getConnection();
	            //searchoption=searchoption.replace(" ","-");
	            PreparedStatement ps=con.prepareStatement("select * from EMP_COMP_OFF_STATUS where COMP_OFF_DATE like ?");  
	            ps.setString(1,"%"+searchoption);
	            ResultSet rs=ps.executeQuery();  
	            while(rs.next()){  
	                Compoff fetchobj=new Compoff();  
	                fetchobj.setEmp_id(rs.getInt(1));  
	               fetchobj.setComp_off_date(rs.getString(2));
	               fetchobj.setWorking_date(rs.getString(3));
	               fetchobj.setStatus(rs.getString(4));
	                list.add(fetchobj);  
	            }  
	            con.close();  
	        }catch(Exception e){e.printStackTrace();}  
	          
	        return list;  
	    }  
}
